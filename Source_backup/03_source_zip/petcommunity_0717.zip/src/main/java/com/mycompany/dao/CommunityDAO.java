package com.mycompany.dao;

public class CommunityDAO {

}
