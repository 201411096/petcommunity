package com.mycompany.dao;

public class CommunityDAOImpl {

}
