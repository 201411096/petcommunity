package com.mycompany.dao;

import com.mycompany.domain.MemberVO;

public interface MemberDAO {
	public int signup(MemberVO vo);
	
	
}
