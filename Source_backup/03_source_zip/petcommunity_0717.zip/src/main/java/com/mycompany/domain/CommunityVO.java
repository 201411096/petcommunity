package com.mycompany.domain;

public class CommunityVO {

}
