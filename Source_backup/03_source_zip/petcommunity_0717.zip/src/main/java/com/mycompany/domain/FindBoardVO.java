package com.mycompany.domain;

public class FindBoardVO {
	private int findboardId;
	private String findboardTitle;
	private String findboardContent;
	private String findboardLocation;
	private String findboardX;
	private String findboardY;
	private String findboardStatus;
	private String findboardUploadtime;
	private String findboardTel;
	private String findboardName;
	private int findboardReadcount;
	private String memberId;
	private String animalId;
	public int getFindboardId() {
		return findboardId;
	}
	public void setFindboardId(int findboardId) {
		this.findboardId = findboardId;
	}
	public String getFindboardTitle() {
		return findboardTitle;
	}
	public void setFindboardTitle(String findboardTitle) {
		this.findboardTitle = findboardTitle;
	}
	public String getFindboardContent() {
		return findboardContent;
	}
	public void setFindboardContent(String findboardContent) {
		this.findboardContent = findboardContent;
	}
	public String getFindboardLocation() {
		return findboardLocation;
	}
	public void setFindboardLocation(String findboardLocation) {
		this.findboardLocation = findboardLocation;
	}
	public String getFindboardX() {
		return findboardX;
	}
	public void setFindboardX(String findboardX) {
		this.findboardX = findboardX;
	}
	public String getFindboardY() {
		return findboardY;
	}
	public void setFindboardY(String findboardY) {
		this.findboardY = findboardY;
	}
	public String getFindboardStatus() {
		return findboardStatus;
	}
	public void setFindboardStatus(String findboardStatus) {
		this.findboardStatus = findboardStatus;
	}
	public String getFindboardUploadtime() {
		return findboardUploadtime;
	}
	public void setFindboardUploadtime(String findboardUploadtime) {
		this.findboardUploadtime = findboardUploadtime;
	}
	public String getFindboardTel() {
		return findboardTel;
	}
	public void setFindboardTel(String findboardTel) {
		this.findboardTel = findboardTel;
	}
	public String getFindboardName() {
		return findboardName;
	}
	public void setFindboardName(String findboardName) {
		this.findboardName = findboardName;
	}
	public int getFindboardReadcount() {
		return findboardReadcount;
	}
	public void setFindboardReadcount(int findboardReadcount) {
		this.findboardReadcount = findboardReadcount;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getAnimalId() {
		return animalId;
	}
	public void setAnimalId(String animalId) {
		this.animalId = animalId;
	}
}
