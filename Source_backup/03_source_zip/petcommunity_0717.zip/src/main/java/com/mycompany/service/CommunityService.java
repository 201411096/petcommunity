package com.mycompany.service;

import org.springframework.stereotype.Service;

@Service("communityService")
public class CommunityService {
	
}
