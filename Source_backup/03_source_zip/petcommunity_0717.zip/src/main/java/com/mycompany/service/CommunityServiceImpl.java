package com.mycompany.service;

import org.springframework.stereotype.Service;


public class CommunityServiceImpl {
	
}
