package com.mycompany.service;

import java.util.List;
import com.mycompany.domain.FindHospitalVO;

public interface FindHospitalService {
	public List<FindHospitalVO> findHospital(FindHospitalVO findHospitalVO);
}
