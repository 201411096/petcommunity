$(function(){
    $('#writeBtn').click(function(){
    	window.location.href='/petcommunity/communityBoardWrite.do';
    });
});