package com.mycompany.domain;

public class ShopVO {
	private String shopId;
	private String shopName;
	private String shopCategory;
	private String shopProductname;
	private String shopProductprice;
	private String shopImg;
	private String shopLink;
	
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopCategory() {
		return shopCategory;
	}
	public void setShopCategory(String shopCategory) {
		this.shopCategory = shopCategory;
	}
	public String getShopProductname() {
		return shopProductname;
	}
	public void setShopProductname(String shopProductname) {
		this.shopProductname = shopProductname;
	}
	public String getShopProductprice() {
		return shopProductprice;
	}
	public void setShopProductprice(String shopProductprice) {
		this.shopProductprice = shopProductprice;
	}
	public String getShopImg() {
		return shopImg;
	}
	public void setShopImg(String shopImg) {
		this.shopImg = shopImg;
	}
	public String getShopLink() {
		return shopLink;
	}
	public void setShopLink(String shopLink) {
		this.shopLink = shopLink;
	}
}
